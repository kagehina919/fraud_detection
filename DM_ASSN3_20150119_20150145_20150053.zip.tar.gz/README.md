This repository runs on Python3. The following modules have been used in the code and hence need to be installed first. Run the following in a python3 environment:    

$ pip install numpy pandas 

Now run:    

$ python3 detect_outlier.py

This will calculate accuraciy and other metrics for different parameter settings which can be changed inside the code.